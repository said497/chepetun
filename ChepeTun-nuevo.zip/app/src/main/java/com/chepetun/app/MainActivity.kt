package com.chepetun.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Properties
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class ServerProfile(val name: String, val host: String, val port: Int, val username: String, val password: String)

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var session: Session? = null
    private var socksServer: Socks5Server? = null
    private val socksPort = 1080
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var picker: Spinner
    private lateinit var status: TextView
    private lateinit var connectButton: Button
    private val profiles = mutableListOf<ServerProfile>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = securePrefs()
        loadProfiles()
        buildUi()
    }

    private fun securePrefs(): android.content.SharedPreferences {
        val key = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            this, "chepetun_secure_profiles", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private fun loadProfiles() {
        val raw = prefs.getString("profiles", "") ?: ""
        profiles.clear()
        raw.lineSequence().filter { it.isNotBlank() }.forEach { line ->
            val p = line.split('\t')
            if (p.size == 5) {
                val port = p[2].toIntOrNull() ?: return@forEach
                profiles.add(ServerProfile(p[0], p[1], port, p[3], p[4]))
            }
        }
    }

    private fun saveProfiles() {
        val raw = profiles.joinToString("\n") {
            listOf(it.name, it.host, it.port.toString(), it.username, it.password).joinToString("\t")
        }
        prefs.edit().putString("profiles", raw).apply()
    }

    private fun buildUi() {
        window.statusBarColor = Color.rgb(13, 32, 48)
        window.navigationBarColor = Color.rgb(13, 32, 48)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(Color.rgb(13, 32, 48))
        }
        root.addView(TextView(this).apply {
            text = "CHEPETUN"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "Tus servidores SSH guardados"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }, matchWrap())

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 20)
            setBackgroundColor(Color.rgb(27, 49, 67))
        }
        root.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })

        picker = Spinner(this)
        refreshPicker()
        panel.addView(picker, matchWrap())

        status = TextView(this).apply {
            text = "ESTADO: DESCONECTADO"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        panel.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 })

        connectButton = Button(this).apply {
            text = "CONECTAR"
            isAllCaps = false
            setOnClickListener {
                if (session?.isConnected == true) disconnect() else connectSelected()
            }
        }
        panel.addView(connectButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })

        val add = Button(this).apply {
            text = "AGREGAR SERVIDOR SSH"
            isAllCaps = false
            setOnClickListener { showAddServerDialog() }
        }
        panel.addView(add, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })

        root.addView(TextView(this).apply {
            text = "Los perfiles se guardan cifrados en este teléfono. ChepeTun no trae servidores gratuitos propios: agrega solo servidores autorizados por su proveedor."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(4, 20, 4, 0)
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "Sin anuncios • SSH con SOCKS5 local"
            textSize = 12f
            setTextColor(Color.rgb(164, 185, 198))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun refreshPicker() {
        val names = if (profiles.isEmpty()) listOf("No hay servidores guardados") else profiles.map { it.name }
        picker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
    }

    private fun showAddServerDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val name = edit("Nombre (ej. Mi servidor)")
        val host = edit("IP o dominio")
        val port = edit("Puerto SSH (22)", "22")
        val user = edit("Usuario SSH")
        val pass = edit("Contraseña SSH")
        pass.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        listOf(name, host, port, user, pass).forEach { layout.addView(it) }
        AlertDialog.Builder(this)
            .setTitle("Agregar servidor autorizado")
            .setView(layout)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar") { _, _ ->
                val n = name.text.toString().trim()
                val h = host.text.toString().trim()
                val p = port.text.toString().toIntOrNull()
                val u = user.text.toString().trim()
                val pw = pass.text.toString()
                if (n.isBlank() || h.isBlank() || p == null || p !in 1..65535 || u.isBlank() || pw.isBlank()) {
                    status.text = "Datos incompletos o puerto inválido"
                } else {
                    profiles.add(ServerProfile(n, h, p, u, pw))
                    saveProfiles()
                    refreshPicker()
                    status.text = "Servidor guardado"
                }
            }.show()
    }

    private fun edit(hintText: String, value: String = "") = EditText(this).apply {
        hint = hintText
        setText(value)
        setSingleLine(true)
    }

    private fun connectSelected() {
        if (profiles.isEmpty() || picker.selectedItemPosition !in profiles.indices) {
            status.text = "Agrega primero un servidor SSH autorizado"
            return
        }
        val profile = profiles[picker.selectedItemPosition]
        connectButton.isEnabled = false
        status.text = "CONECTANDO A ${profile.name}…"
        executor.execute {
            try {
                val jsch = JSch()
                val s = jsch.getSession(profile.username, profile.host, profile.port)
                s.setPassword(profile.password)
                s.setConfig(Properties().apply {
                    put("StrictHostKeyChecking", "yes")
                    put("PreferredAuthentications", "publickey,password,keyboard-interactive")
                })
                s.connect(15000)
                val proxy = Socks5Server(s, socksPort)
                proxy.start()
                session = s
                socksServer = proxy
                runOnUiThread {
                    status.text = "CONECTADO • SOCKS5 127.0.0.1:$socksPort"
                    connectButton.text = "DESCONECTAR"
                    connectButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "No conectó: ${e.message ?: "error SSH"}"
                    connectButton.isEnabled = true
                }
            }
        }
    }

    private fun disconnect() {
        executor.execute {
            try { socksServer?.stop() } catch (_: Exception) {}
            socksServer = null
            try { session?.disconnect() } catch (_: Exception) {}
            session = null
            runOnUiThread {
                status.text = "ESTADO: DESCONECTADO"
                connectButton.text = "CONECTAR"
            }
        }
    }

    override fun onDestroy() {
        try { socksServer?.stop() } catch (_: Exception) {}
        try { session?.disconnect() } catch (_: Exception) {}
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}

/** SOCKS5 local proxy: each requested destination is carried by an SSH direct-tcpip channel. */
private class Socks5Server(private val ssh: Session, private val port: Int) {
    private val running = AtomicBoolean(false)
    private var server: ServerSocket? = null
    private val clients = Executors.newCachedThreadPool()

    fun start() {
        server = ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))
        running.set(true)
        Thread {
            while (running.get()) {
                try {
                    val socket = server?.accept() ?: break
                    clients.execute { handle(socket) }
                } catch (_: Exception) {
                    if (running.get()) stop()
                }
            }
        }.apply { name = "ChepeTun-SOCKS5-Accept"; isDaemon = true }.start()
    }

    private fun handle(socket: Socket) {
        var channel: ChannelDirectTCPIP? = null
        try {
            socket.soTimeout = 20000
            val input = socket.getInputStream()
            val output = socket.getOutputStream()
            if (input.read() != 5) return
            val methodCount = input.read()
            if (methodCount < 0) return
            repeat(methodCount) { input.read() }
            output.write(byteArrayOf(5, 0))
            output.flush()

            if (input.read() != 5) return
            val command = input.read()
            input.read() // reserved
            val addressType = input.read()
            if (command != 1) {
                output.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0)); output.flush(); return
            }
            val host = when (addressType) {
                1 -> readExactly(input, 4).joinToString(".") { (it.toInt() and 0xff).toString() }
                3 -> {
                    val length = input.read()
                    String(readExactly(input, length), Charsets.UTF_8)
                }
                4 -> InetAddress.getByAddress(readExactly(input, 16)).hostAddress
                else -> {
                    output.write(byteArrayOf(5, 8, 0, 1, 0, 0, 0, 0, 0, 0)); output.flush(); return
                }
            }
            val portBytes = readExactly(input, 2)
            if (portBytes.size != 2) return
            val remotePort = ((portBytes[0].toInt() and 0xff) shl 8) or (portBytes[1].toInt() and 0xff)

            channel = ssh.openChannel("direct-tcpip") as ChannelDirectTCPIP
            channel.setHost(host)
            channel.setPort(remotePort)
            channel.setInputStream(input)
            channel.setOutputStream(output)
            channel.connect(15000)
            socket.soTimeout = 0
            output.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0))
            output.flush()
            while (running.get() && !socket.isClosed && channel.isConnected) Thread.sleep(250)
        } catch (_: Exception) {
            try {
                socket.getOutputStream().write(byteArrayOf(5, 5, 0, 1, 0, 0, 0, 0, 0, 0))
                socket.getOutputStream().flush()
            } catch (_: Exception) {}
        } finally {
            try { channel?.disconnect() } catch (_: Exception) {}
            try { socket.close() } catch (_: Exception) {}
        }
    }

    fun stop() {
        running.set(false)
        try { server?.close() } catch (_: Exception) {}
        clients.shutdownNow()
    }
}


private fun readExactly(input: java.io.InputStream, length: Int): ByteArray {
    val result = ByteArray(length)
    var offset = 0
    while (offset < length) {
        val count = input.read(result, offset, length - offset)
        if (count < 0) throw java.io.EOFException("Conexión SOCKS cerrada")
        offset += count
    }
    return result
}
