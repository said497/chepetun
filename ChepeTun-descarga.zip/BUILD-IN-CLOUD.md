# Compilación en la nube

Este proyecto incluye `.github/workflows/android-apk.yml`, que compila un APK de depuración en GitHub Actions.

## Pasos necesarios (una sola vez)
1. Crear/iniciar sesión en GitHub.
2. Crear un repositorio nuevo y subir el contenido de este ZIP.
3. Abrir la pestaña **Actions**.
4. Seleccionar **Build ChepeTun APK** y pulsar **Run workflow**.
5. Cuando termine, abrir la ejecución y descargar el artefacto **ChepeTun-debug-apk**.

## Importante
- Esto genera un APK de depuración, no una app publicada ni firmada para distribución.
- El proyecto actual implementa cliente SSH con reenvío SOCKS5 local. No implementa `VpnService`, tun2socks, SNI/payload, ni servidores propios incluidos.
- Para probar SSH se requiere un servidor y una cuenta autorizados. No subir contraseñas, claves privadas ni credenciales al repositorio.
- Antes de usarlo con credenciales reales, se debe implementar y verificar el pinning/almacenamiento de la clave del host SSH. La app mantiene `StrictHostKeyChecking=yes`, por lo que no acepta hosts desconocidos a ciegas.
