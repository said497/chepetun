# ChepeTun 0.3.0 — perfiles SSH guardados

## Incluye
- Selector de perfiles SSH guardados.
- Formulario para agregar servidores autorizados.
- Credenciales almacenadas mediante Android EncryptedSharedPreferences.
- Conexión SSH y reenvío dinámico SOCKS5 local en 127.0.0.1:1080.
- Sin SDK publicitarios.

## Límites reales
- No trae servidores gratuitos integrados: no existe un servidor público que podamos incluir legítimamente sin permiso del proveedor.
- El usuario debe agregar una cuenta SSH autorizada una vez; después queda guardada cifrada en el dispositivo y se puede seleccionar sin volver a escribirla.
- No es aún una VPN de todo el dispositivo. SOCKS5 debe usarse con una app que lo soporte.
- StrictHostKeyChecking está activado; para servidores no conocidos se requiere instalar/validar la clave de host de forma segura. No se desactiva la verificación por comodidad.
- No implementa SNI/payload ni Android VpnService.

## Compilar
Abrir en Android Studio (JDK 17), sincronizar Gradle y ejecutar `app`.
